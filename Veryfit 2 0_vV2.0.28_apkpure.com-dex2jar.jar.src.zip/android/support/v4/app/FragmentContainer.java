package android.support.v4.app;

import android.view.View;

abstract interface FragmentContainer
{
  public abstract View findViewById(int paramInt);
  
  public abstract boolean hasView();
}


/* Location:              C:\Users\julian\Downloads\Veryfit 2 0_vV2.0.28_apkpure.com-dex2jar.jar!\android\support\v4\app\FragmentContainer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */