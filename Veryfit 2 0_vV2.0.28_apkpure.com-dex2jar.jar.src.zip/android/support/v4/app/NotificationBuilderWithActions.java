package android.support.v4.app;

abstract interface NotificationBuilderWithActions
{
  public abstract void addAction(NotificationCompatBase.Action paramAction);
}


/* Location:              C:\Users\julian\Downloads\Veryfit 2 0_vV2.0.28_apkpure.com-dex2jar.jar!\android\support\v4\app\NotificationBuilderWithActions.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */