package android.support.v4.view;

import android.view.View;

public class ViewPropertyAnimatorListenerAdapter
  implements ViewPropertyAnimatorListener
{
  public void onAnimationCancel(View paramView) {}
  
  public void onAnimationEnd(View paramView) {}
  
  public void onAnimationStart(View paramView) {}
}


/* Location:              C:\Users\julian\Downloads\Veryfit 2 0_vV2.0.28_apkpure.com-dex2jar.jar!\android\support\v4\view\ViewPropertyAnimatorListenerAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */