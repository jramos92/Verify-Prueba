package cn.sharesdk.whatsapp;

public class WhatsAppClientNotExistException
  extends RuntimeException
{
  private static final long serialVersionUID = -696033851081496222L;
}


/* Location:              C:\Users\julian\Downloads\Veryfit 2 0_vV2.0.28_apkpure.com-dex2jar.jar!\cn\sharesdk\whatsapp\WhatsAppClientNotExistException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */