package cn.sharesdk.tencent.qzone;

import android.view.View;
import android.view.View.OnClickListener;

class j
  implements View.OnClickListener
{
  j(i parami) {}
  
  public void onClick(View paramView)
  {
    new k(this).start();
  }
}


/* Location:              C:\Users\julian\Downloads\Veryfit 2 0_vV2.0.28_apkpure.com-dex2jar.jar!\cn\sharesdk\tencent\qzone\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */