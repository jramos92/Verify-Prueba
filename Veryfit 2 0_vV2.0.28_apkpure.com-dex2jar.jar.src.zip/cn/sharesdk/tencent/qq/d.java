package cn.sharesdk.tencent.qq;

import com.mob.tools.log.NLog;

class d
  extends Thread
{
  d(c paramc, String paramString) {}
  
  public void run()
  {
    try
    {
      this.b.a(this.a);
      return;
    }
    catch (Throwable localThrowable)
    {
      cn.sharesdk.framework.utils.d.a().w(localThrowable);
    }
  }
}


/* Location:              C:\Users\julian\Downloads\Veryfit 2 0_vV2.0.28_apkpure.com-dex2jar.jar!\cn\sharesdk\tencent\qq\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */