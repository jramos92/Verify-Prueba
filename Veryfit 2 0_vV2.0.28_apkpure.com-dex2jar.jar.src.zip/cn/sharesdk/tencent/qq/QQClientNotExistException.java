package cn.sharesdk.tencent.qq;

public class QQClientNotExistException
  extends RuntimeException
{
  private static final long serialVersionUID = -4646831863162587967L;
}


/* Location:              C:\Users\julian\Downloads\Veryfit 2 0_vV2.0.28_apkpure.com-dex2jar.jar!\cn\sharesdk\tencent\qq\QQClientNotExistException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */