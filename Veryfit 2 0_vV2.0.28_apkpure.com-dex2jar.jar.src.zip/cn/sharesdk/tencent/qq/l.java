package cn.sharesdk.tencent.qq;

import android.view.View;
import android.view.View.OnClickListener;

class l
  implements View.OnClickListener
{
  l(k paramk) {}
  
  public void onClick(View paramView)
  {
    new m(this).start();
  }
}


/* Location:              C:\Users\julian\Downloads\Veryfit 2 0_vV2.0.28_apkpure.com-dex2jar.jar!\cn\sharesdk\tencent\qq\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */