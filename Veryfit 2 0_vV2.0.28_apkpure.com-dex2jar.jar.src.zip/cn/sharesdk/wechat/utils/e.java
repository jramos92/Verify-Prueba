package cn.sharesdk.wechat.utils;

import android.os.Bundle;

public class e
  extends WechatResp
{
  public e(Bundle paramBundle)
  {
    super(paramBundle);
  }
  
  public int a()
  {
    return 2;
  }
}


/* Location:              C:\Users\julian\Downloads\Veryfit 2 0_vV2.0.28_apkpure.com-dex2jar.jar!\cn\sharesdk\wechat\utils\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */