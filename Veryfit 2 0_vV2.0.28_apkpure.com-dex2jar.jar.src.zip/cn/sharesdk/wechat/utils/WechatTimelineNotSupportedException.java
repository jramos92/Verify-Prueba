package cn.sharesdk.wechat.utils;

public class WechatTimelineNotSupportedException
  extends Exception
{
  private static final long serialVersionUID = -1845654836418110059L;
}


/* Location:              C:\Users\julian\Downloads\Veryfit 2 0_vV2.0.28_apkpure.com-dex2jar.jar!\cn\sharesdk\wechat\utils\WechatTimelineNotSupportedException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */