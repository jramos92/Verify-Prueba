package cn.sharesdk.framework.statistics.a;

import java.util.ArrayList;

public class d
{
  public String a;
  public ArrayList<String> b = new ArrayList();
}


/* Location:              C:\Users\julian\Downloads\Veryfit 2 0_vV2.0.28_apkpure.com-dex2jar.jar!\cn\sharesdk\framework\statistics\a\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */