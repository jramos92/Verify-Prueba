package cn.sharesdk.framework.utils;

final class i
  extends ThreadLocal<char[]>
{
  protected char[] a()
  {
    return new char['Ѐ'];
  }
}


/* Location:              C:\Users\julian\Downloads\Veryfit 2 0_vV2.0.28_apkpure.com-dex2jar.jar!\cn\sharesdk\framework\utils\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */