package cn.sharesdk.framework;

import android.content.Context;
import android.widget.ImageView;
import android.widget.TextView;

class n
  extends TextView
{
  n(TitleLayout paramTitleLayout, Context paramContext, ImageView paramImageView)
  {
    super(paramContext);
  }
  
  public void setVisibility(int paramInt)
  {
    super.setVisibility(paramInt);
    this.a.setVisibility(paramInt);
  }
}


/* Location:              C:\Users\julian\Downloads\Veryfit 2 0_vV2.0.28_apkpure.com-dex2jar.jar!\cn\sharesdk\framework\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */