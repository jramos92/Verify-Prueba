package cn.sharesdk.framework.authorize;

import android.view.View;
import android.view.View.OnClickListener;

class h
  implements View.OnClickListener
{
  h(g paramg) {}
  
  public void onClick(View paramView)
  {
    new i(this).start();
  }
}


/* Location:              C:\Users\julian\Downloads\Veryfit 2 0_vV2.0.28_apkpure.com-dex2jar.jar!\cn\sharesdk\framework\authorize\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */