package cn.sharesdk.instagram;

public class InstagramClientNotExistException
  extends RuntimeException
{
  private static final long serialVersionUID = 5387005742820877169L;
}


/* Location:              C:\Users\julian\Downloads\Veryfit 2 0_vV2.0.28_apkpure.com-dex2jar.jar!\cn\sharesdk\instagram\InstagramClientNotExistException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */