package cn.sharesdk.facebook;

import cn.sharesdk.framework.authorize.g;

class d
  implements Runnable
{
  d(c paramc) {}
  
  public void run()
  {
    c.a(this.a).finish();
  }
}


/* Location:              C:\Users\julian\Downloads\Veryfit 2 0_vV2.0.28_apkpure.com-dex2jar.jar!\cn\sharesdk\facebook\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */