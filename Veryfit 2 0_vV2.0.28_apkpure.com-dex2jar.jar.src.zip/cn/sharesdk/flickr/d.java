package cn.sharesdk.flickr;

import com.mob.tools.log.NLog;

class d
  extends Thread
{
  d(c paramc, String paramString) {}
  
  public void run()
  {
    try
    {
      c.a(this.b, this.a);
      return;
    }
    catch (Throwable localThrowable)
    {
      cn.sharesdk.framework.utils.d.a().w(localThrowable);
    }
  }
}


/* Location:              C:\Users\julian\Downloads\Veryfit 2 0_vV2.0.28_apkpure.com-dex2jar.jar!\cn\sharesdk\flickr\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */